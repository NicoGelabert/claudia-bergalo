<!-- Footer
		============================================= -->
		<footer id="footer" class="dark">

			<!-- Copyrights
			============================================= -->
			<div id="copyrights">
				<div class="container">

					<div class="row col-mb-30">

						<div class="col-md-6 text-center text-md-left">
							<img src="/storage/images/brand/isologotipo-Claudia-Bergalo.png" style="height:75px" alt=""><br>
							Copyrights &copy; 2020 Todos los derechos reservados
						</div>

						<div class="col-md-6 text-center text-md-right">
							<div class="d-flex justify-content-center justify-content-md-end">
								<a href="https://www.facebook.com/claudiabergalolocutora/" class="social-icon si-small si-borderless si-facebook" target="_blank">
									<i class="icon-facebook"></i>
									<i class="icon-facebook"></i>
								</a>

								<a href="https://twitter.com/clau_bergalo?lang=es" class="social-icon si-small si-borderless si-twitter" target="_blank">
									<i class="icon-twitter"></i>
									<i class="icon-twitter"></i>
								</a>

								<a href="https://www.instagram.com/claubergalo/?hl=es-la" class="social-icon si-small si-borderless si-instagram" target="_blank">
									<i class="icon-instagram"></i>
									<i class="icon-instagram"></i>
								</a>

								<a href="https://www.youtube.com/channel/UC4M9biZjsrNgKmxKUNDcWZA" class="social-icon si-small si-borderless si-youtube" target="_blank">
									<i class="icon-youtube"></i>
									<i class="icon-youtube"></i>
								</a>

								<a href="https://www.linkedin.com/in/claudia-bergalo-6a5989125/?originalSubdomain=ar" class="social-icon si-small si-borderless si-linkedin" target="_blank">
									<i class="icon-linkedin"></i>
									<i class="icon-linkedin"></i>
								</a>
							</div>

							<div class="clear"></div>

							<i class="icon-envelope2"></i> claubergalo@hotmail.com
							<br><i class="icon-headphones"></i> +54-9-11-5887-9994
							<!-- <br><i class="icon-skype2"></i> CanvasOnSkype -->
						</div>

					</div>

				</div>
			</div><!-- #copyrights end -->
		</footer><!-- #footer end --><?php /**PATH C:\Claudia Bergalo\claudia-bergalo\resources\views/partials/footer.blade.php ENDPATH**/ ?>